import 'package:flutter/material.dart';
import '../models/book.dart';

/// Shows assets/covers/<book.id>.jpg if present, else a colored placeholder.
class BookCover extends StatelessWidget {
  final Book book;
  final double width;
  const BookCover({super.key, required this.book, this.width = 120});

  Widget _fallback() {
    final hue = (book.colorSeed * 57) % 360;
    final c = HSLColor.fromAHSL(1, hue.toDouble(), 0.45, 0.35).toColor();
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        gradient: LinearGradient(
            colors: [c, c.withValues(alpha: 0.7)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight),
      ),
      alignment: Alignment.bottomLeft,
      child: Text(book.titleBn,
          maxLines: 4,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(
              color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
    );
  }

  @override
  Widget build(BuildContext context) => SizedBox(
        width: width,
        height: width * 1.45,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Image.asset(
            'assets/covers/${book.id}.jpg',
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => _fallback(),
          ),
        ),
      );
}
