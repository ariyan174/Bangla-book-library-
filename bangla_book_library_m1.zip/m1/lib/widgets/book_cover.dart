import 'package:flutter/material.dart';
import '../models/book.dart';

/// Placeholder cover (no external image). Real covers come from Storage later.
class BookCover extends StatelessWidget {
  final Book book;
  final double width;
  const BookCover({super.key, required this.book, this.width = 120});
  @override
  Widget build(BuildContext context) {
    final hue = (book.colorSeed * 57) % 360;
    final c = HSLColor.fromAHSL(1, hue.toDouble(), 0.45, 0.35).toColor();
    return Container(
      width: width,
      height: width * 1.45,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        gradient: LinearGradient(
            colors: [c, c.withValues(alpha: 0.7)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight),
      ),
      alignment: Alignment.bottomLeft,
      child: Text(book.titleBn,
          maxLines: 4,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(
              color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
    );
  }
}
