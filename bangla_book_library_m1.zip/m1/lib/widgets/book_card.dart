import 'package:flutter/material.dart';
import '../models/book.dart';
import '../screens/book_details_screen.dart';
import 'book_cover.dart';

class BookCard extends StatelessWidget {
  final Book book;
  const BookCard({super.key, required this.book});
  @override
  Widget build(BuildContext context) => InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => BookDetailsScreen(book: book))),
        child: SizedBox(
          width: 120,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            BookCover(book: book),
            const SizedBox(height: 6),
            Text(book.titleBn,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: Theme.of(context).textTheme.labelLarge),
            Text(book.author,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: Theme.of(context).textTheme.bodySmall),
          ]),
        ),
      );
}
