import 'package:flutter/material.dart';
import 'app/theme.dart';
import 'app/shell.dart';

void main() => runApp(const BanglaBookLibraryApp());

class BanglaBookLibraryApp extends StatelessWidget {
  const BanglaBookLibraryApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Bangla Book Library',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.build(Brightness.light),
        darkTheme: AppTheme.build(Brightness.dark),
        themeMode: ThemeMode.system,
        home: const AppShell(),
      );
}
