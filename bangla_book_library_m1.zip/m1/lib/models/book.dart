enum RightsStatus { summaryOnly, publicDomain, licensed }

class Book {
  final String id, titleEn, titleBn, author, categoryId, descriptionBn;
  final List<String> lessonsBn;
  final RightsStatus rights;
  final int colorSeed;
  const Book({
    required this.id,
    required this.titleEn,
    required this.titleBn,
    required this.author,
    required this.categoryId,
    required this.descriptionBn,
    required this.lessonsBn,
    this.rights = RightsStatus.summaryOnly,
    this.colorSeed = 0,
  });
  bool get fullTextAvailable => rights != RightsStatus.summaryOnly;
}

class Category {
  final String id, nameBn, nameEn;
  const Category(this.id, this.nameBn, this.nameEn);
}
