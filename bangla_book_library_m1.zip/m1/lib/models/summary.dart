class BookSummary {
  final String intro, about;
  final List<String> concepts, lessons, examples, actions, takeaways, questions;
  const BookSummary({
    required this.intro,
    required this.about,
    required this.concepts,
    required this.lessons,
    required this.examples,
    required this.actions,
    required this.takeaways,
    required this.questions,
  });
}
