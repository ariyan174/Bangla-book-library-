import 'package:flutter/material.dart';

class PlaceholderScreen extends StatelessWidget {
  final String title, note;
  final IconData icon;
  const PlaceholderScreen(
      {super.key, required this.title, required this.note, required this.icon});
  @override
  Widget build(BuildContext context) => SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(32),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(icon, size: 56),
              const SizedBox(height: 12),
              Text(title, style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 6),
              Text(note, textAlign: TextAlign.center),
            ]),
          ),
        ),
      );
}
