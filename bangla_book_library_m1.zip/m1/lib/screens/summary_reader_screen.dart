import 'package:flutter/material.dart';
import '../models/book.dart';
import '../models/summary.dart';

class SummaryReaderScreen extends StatefulWidget {
  final Book book;
  final BookSummary summary;
  const SummaryReaderScreen(
      {super.key, required this.book, required this.summary});
  @override
  State<SummaryReaderScreen> createState() => _SummaryReaderScreenState();
}

class _SummaryReaderScreenState extends State<SummaryReaderScreen> {
  double _size = 17;
  bool _sepia = false;

  @override
  Widget build(BuildContext context) {
    final s = widget.summary;
    final sepiaBg = const Color(0xFFF4ECD8);
    final sepiaFg = const Color(0xFF3B2F1E);
    final fg = _sepia ? sepiaFg : Theme.of(context).colorScheme.onSurface;
    final sections = <(String, List<String>, bool)>[
      ('বই পরিচিতি', [s.intro], false),
      ('বইটি কী নিয়ে', [s.about], false),
      ('মূল ধারণা', s.concepts, true),
      ('প্রধান শিক্ষা', s.lessons, true),
      ('বাস্তব জীবনের উদাহরণ', s.examples, true),
      ('করণীয় ধাপ', s.actions, true),
      ('গুরুত্বপূর্ণ সারকথা', s.takeaways, true),
      ('ভাবনার প্রশ্ন', s.questions, true),
    ];
    return Scaffold(
      backgroundColor: _sepia ? sepiaBg : null,
      appBar: AppBar(
        backgroundColor: _sepia ? sepiaBg : null,
        foregroundColor: fg,
        title: Text(widget.book.titleBn, overflow: TextOverflow.ellipsis),
        actions: [
          IconButton(
              tooltip: 'ছোট অক্ষর',
              icon: const Icon(Icons.text_decrease),
              onPressed: () =>
                  setState(() => _size = (_size - 1).clamp(13, 28))),
          IconButton(
              tooltip: 'বড় অক্ষর',
              icon: const Icon(Icons.text_increase),
              onPressed: () =>
                  setState(() => _size = (_size + 1).clamp(13, 28))),
          IconButton(
              tooltip: 'পড়ার রঙ',
              icon: Icon(_sepia ? Icons.dark_mode : Icons.wb_sunny_outlined),
              onPressed: () => setState(() => _sepia = !_sepia)),
        ],
      ),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        for (final sec in sections) ...[
          Text(sec.$1,
              style: TextStyle(
                  fontSize: _size + 3,
                  fontWeight: FontWeight.w700,
                  color: fg)),
          const SizedBox(height: 8),
          for (final p in sec.$2)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                if (sec.$3)
                  Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: Text('•', style: TextStyle(fontSize: _size, color: fg))),
                Expanded(
                    child: Text(p,
                        style:
                            TextStyle(fontSize: _size, height: 1.8, color: fg))),
              ]),
            ),
          const SizedBox(height: 14),
        ],
        Text(
          'এটি মৌলিক বাংলা সারসংক্ষেপ, বইয়ের বিকল্প নয়। পূর্ণ অভিজ্ঞতার জন্য মূল বইটি পড়ুন।',
          style: TextStyle(fontSize: 12, color: fg.withValues(alpha: 0.7)),
        ),
      ]),
    );
  }
}
