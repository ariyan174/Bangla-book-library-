import 'package:flutter/material.dart';
import '../data/sample_data.dart';
import '../models/book.dart';
import '../widgets/book_card.dart';

class CategoriesScreen extends StatelessWidget {
  const CategoriesScreen({super.key});

  Widget _tile(Category c, bool bySkill) {
    final items = sampleBooks
        .where((b) => bySkill ? b.skillId == c.id : b.categoryId == c.id)
        .toList();
    return ExpansionTile(
      title: Text(c.nameBn),
      subtitle: Text('${c.nameEn} • ${items.length}টি বই'),
      children: [
        if (items.isEmpty)
          const Padding(
              padding: EdgeInsets.all(16),
              child: Text('এই বিভাগে এখনো বই নেই'))
        else
          Padding(
            padding: const EdgeInsets.all(12),
            child: Wrap(spacing: 12, runSpacing: 12, children: [
              for (final b in items) BookCard(book: b)
            ]),
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context).textTheme;
    return SafeArea(
      child: ListView(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
          child: Text('দক্ষতা অনুযায়ী', style: t.titleLarge),
        ),
        for (final c in skills) _tile(c, true),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 24, 16, 4),
          child: Text('বিষয় অনুযায়ী', style: t.titleLarge),
        ),
        for (final c in categories) _tile(c, false),
      ]),
    );
  }
}
