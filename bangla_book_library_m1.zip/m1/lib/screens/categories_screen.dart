import 'package:flutter/material.dart';
import '../data/sample_data.dart';
import '../widgets/book_card.dart';

class CategoriesScreen extends StatelessWidget {
  const CategoriesScreen({super.key});
  @override
  Widget build(BuildContext context) => SafeArea(
        child: ListView(children: [
          for (final c in categories)
            ExpansionTile(
              title: Text(c.nameBn),
              subtitle: Text(c.nameEn),
              children: [
                Builder(builder: (_) {
                  final items =
                      sampleBooks.where((b) => b.categoryId == c.id).toList();
                  if (items.isEmpty) {
                    return const Padding(
                        padding: EdgeInsets.all(16),
                        child: Text('এই বিভাগে এখনো বই নেই'));
                  }
                  return Padding(
                    padding: const EdgeInsets.all(12),
                    child: Wrap(
                        spacing: 12,
                        runSpacing: 12,
                        children: [for (final b in items) BookCard(book: b)]),
                  );
                }),
              ],
            ),
        ]),
      );
}
