import 'package:flutter/material.dart';
import '../data/sample_data.dart';
import '../models/book.dart';
import '../widgets/book_cover.dart';

class BookDetailsScreen extends StatelessWidget {
  final Book book;
  const BookDetailsScreen({super.key, required this.book});

  String get _rightsLabel => switch (book.rights) {
        RightsStatus.summaryOnly => 'শুধু মৌলিক সারসংক্ষেপ',
        RightsStatus.publicDomain => 'পাবলিক ডোমেইন',
        RightsStatus.licensed => 'লাইসেন্সপ্রাপ্ত',
      };

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context);
    final cat = categories.firstWhere((c) => c.id == book.categoryId);
    return Scaffold(
      appBar: AppBar(title: Text(book.titleBn, overflow: TextOverflow.ellipsis)),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          BookCover(book: book, width: 130),
          const SizedBox(width: 16),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(book.titleEn, style: t.textTheme.titleLarge),
              const SizedBox(height: 4),
              Text(book.author, style: t.textTheme.bodyMedium),
              const SizedBox(height: 8),
              Chip(label: Text(cat.nameBn)),
              Chip(
                  avatar: const Icon(Icons.verified_outlined, size: 16),
                  label: Text(_rightsLabel)),
            ]),
          ),
        ]),
        const SizedBox(height: 20),
        Text('বই পরিচিতি', style: t.textTheme.titleMedium),
        const SizedBox(height: 6),
        Text(book.descriptionBn, style: t.textTheme.bodyLarge?.copyWith(height: 1.7)),
        const SizedBox(height: 20),
        Text('প্রধান শিক্ষা', style: t.textTheme.titleMedium),
        const SizedBox(height: 6),
        for (final l in book.lessonsBn)
          ListTile(
              dense: true,
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.check_circle_outline),
              title: Text(l)),
        const SizedBox(height: 16),
        FilledButton.icon(
          onPressed: null,
          icon: const Icon(Icons.auto_stories),
          label: const Text('সারসংক্ষেপ পড়ুন (Milestone 3)'),
        ),
        const SizedBox(height: 8),
        Text(
          book.fullTextAvailable
              ? 'পূর্ণ পাঠ্য উপলব্ধ।'
              : 'এই বইয়ের পূর্ণ পাঠ্য নেই; শুধু মৌলিক সারসংক্ষেপ দেখানো হয়।',
          style: t.textTheme.bodySmall,
        ),
      ]),
    );
  }
}
