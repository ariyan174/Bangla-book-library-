import 'package:flutter/material.dart';
import '../data/sample_data.dart';
import '../models/book.dart';
import '../widgets/book_card.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _q = '';

  List<Book> get _results {
    final q = _q.trim().toLowerCase();
    return sampleBooks
        .where((b) =>
            b.titleEn.toLowerCase().contains(q) ||
            b.titleBn.contains(q) ||
            b.author.toLowerCase().contains(q))
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context);
    return SafeArea(
      child: ListView(padding: const EdgeInsets.all(16), children: [
        Text('বাংলা বুক লাইব্রেরি', style: t.textTheme.headlineSmall),
        const SizedBox(height: 12),
        SearchBar(
          hintText: 'বই বা লেখক খুঁজুন',
          leading: const Icon(Icons.search),
          onChanged: (v) => setState(() => _q = v),
        ),
        const SizedBox(height: 16),
        if (_q.trim().isNotEmpty) ...[
          if (_results.isEmpty)
            const Padding(
                padding: EdgeInsets.all(32),
                child: Center(child: Text('কোনো বই পাওয়া যায়নি')))
          else
            _Shelf(title: 'ফলাফল', books: _results),
        ] else ...[
          Card(
            color: t.colorScheme.surfaceContainerHighest,
            child: const ListTile(
              leading: Icon(Icons.menu_book_outlined),
              title: Text('পড়া চালিয়ে যান'),
              subtitle: Text('এখনো কোনো বই শুরু করেননি'),
            ),
          ),
          const SizedBox(height: 16),
          const _Shelf(title: 'নমুনা বই (স্যাম্পল ডেটা)', books: sampleBooks),
          const SizedBox(height: 16),
          _Shelf(
              title: 'সম্প্রতি যোগ হয়েছে (স্যাম্পল)',
              books: sampleBooks.reversed.toList()),
        ],
      ]),
    );
  }
}

class _Shelf extends StatelessWidget {
  final String title;
  final List<Book> books;
  const _Shelf({required this.title, required this.books});
  @override
  Widget build(BuildContext context) =>
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 10),
        SizedBox(
          height: 120 * 1.45 + 64,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: books.length,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (_, i) => BookCard(book: books[i]),
          ),
        ),
      ]);
}
