import 'package:flutter/material.dart';
import '../screens/home_screen.dart';
import '../screens/categories_screen.dart';
import '../screens/placeholder_screen.dart';

class AppShell extends StatefulWidget {
  const AppShell({super.key});
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _i = 0;
  static const _pages = <Widget>[
    HomeScreen(),
    CategoriesScreen(),
    PlaceholderScreen(
        title: 'আমার লাইব্রেরি',
        note: 'বুকমার্ক ও সংরক্ষিত বই Milestone 3-এ আসবে।',
        icon: Icons.bookmarks_outlined),
    PlaceholderScreen(
        title: 'এআই শিক্ষক',
        note: 'নিরাপদ সার্ভার-সাইড এআই Milestone 4-এ আসবে।',
        icon: Icons.smart_toy_outlined),
    PlaceholderScreen(
        title: 'প্রোফাইল',
        note: 'লগইন ও সেটিংস Milestone 2-এ আসবে।',
        icon: Icons.person_outline),
  ];

  @override
  Widget build(BuildContext context) => Scaffold(
        body: IndexedStack(index: _i, children: _pages),
        bottomNavigationBar: NavigationBar(
          selectedIndex: _i,
          onDestinationSelected: (v) => setState(() => _i = v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'হোম'),
            NavigationDestination(icon: Icon(Icons.category_outlined), selectedIcon: Icon(Icons.category), label: 'বিভাগ'),
            NavigationDestination(icon: Icon(Icons.bookmarks_outlined), selectedIcon: Icon(Icons.bookmarks), label: 'লাইব্রেরি'),
            NavigationDestination(icon: Icon(Icons.smart_toy_outlined), selectedIcon: Icon(Icons.smart_toy), label: 'এআই শিক্ষক'),
            NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'প্রোফাইল'),
          ],
        ),
      );
}
