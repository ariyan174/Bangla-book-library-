import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  static ThemeData build(Brightness b) {
    final scheme = ColorScheme.fromSeed(
        seedColor: const Color(0xFF1B5E52), brightness: b);
    final base = ThemeData(colorScheme: scheme, useMaterial3: true);
    return base.copyWith(
      textTheme: GoogleFonts.notoSansBengaliTextTheme(base.textTheme),
      appBarTheme: const AppBarTheme(centerTitle: false),
    );
  }
}
