import 'deep_a.dart';
import 'deep_b.dart';
import 'deep_c.dart';
import 'deep_d.dart';
import 'deep_e.dart';

// ১০টি বইয়ের গভীর অধ্যায়ভিত্তিক আলোচনা। থাকলে এটি পুরোনো সংক্ষিপ্ত অধ্যায়ের বদলে দেখানো হয়।
final Map<String, List<(String, String)>> deepChapters = {
  ...deepA,
  ...deepB,
  ...deepC,
  ...deepD,
  ...deepE,
};
