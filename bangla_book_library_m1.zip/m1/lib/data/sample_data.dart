import '../models/book.dart';

// SAMPLE DATA ONLY. Replaced by Firestore in Milestone 2.
const categories = <Category>[
  Category('personal_development', 'ব্যক্তিগত উন্নয়ন', 'Personal Development'),
  Category('psychology', 'মনোবিজ্ঞান ও মানব আচরণ', 'Psychology and Human Behavior'),
  Category('money', 'অর্থ ও ব্যক্তিগত অর্থায়ন', 'Money and Personal Finance'),
  Category('power_strategy', 'ক্ষমতা ও কৌশল', 'Power and Strategy'),
  Category('communication', 'যোগাযোগ ও প্ররোচনা', 'Communication and Persuasion'),
  Category('habits', 'অভ্যাস ও উৎপাদনশীলতা', 'Habits and Productivity'),
  Category('philosophy', 'দর্শন ও স্টোইসিজম', 'Philosophy and Stoicism'),
  Category('leadership', 'নেতৃত্ব ও ব্যবসা', 'Leadership and Business'),
  Category('learning', 'শেখা ও সমালোচনামূলক চিন্তা', 'Learning and Critical Thinking'),
  Category('biography', 'জীবনী ও স্মৃতিকথা', 'Biography and Memoir'),
];

const sampleBooks = <Book>[
  Book(
    id: 'atomic-habits', titleEn: 'Atomic Habits', titleBn: 'অ্যাটমিক হ্যাবিটস',
    author: 'James Clear', categoryId: 'habits', colorSeed: 1,
    descriptionBn: 'ছোট ছোট অভ্যাস কীভাবে সময়ের সঙ্গে বড় পরিবর্তন আনে, তা নিয়ে একটি বই।',
    lessonsBn: ['ছোট পরিবর্তন জমতে জমতে বড় ফল দেয়।', 'লক্ষ্যের চেয়ে প্রক্রিয়ার ওপর মনোযোগ দিন।', 'ভালো অভ্যাস সহজ ও আকর্ষণীয় করুন।'],
  ),
  Book(
    id: 'psychology-of-money', titleEn: 'The Psychology of Money', titleBn: 'দ্য সাইকোলজি অব মানি',
    author: 'Morgan Housel', categoryId: 'money', colorSeed: 2,
    descriptionBn: 'অর্থ নিয়ে আমাদের আচরণ ও মানসিকতা কীভাবে সিদ্ধান্তকে প্রভাবিত করে, তা আলোচনা করে।',
    lessonsBn: ['টাকা সামলানো জ্ঞানের চেয়ে আচরণের বিষয়।', 'ধৈর্য ও সময় সম্পদ গড়ার মূল শক্তি।', 'প্রয়োজনের বেশি ঝুঁকি এড়িয়ে চলুন।'],
  ),
  Book(
    id: 'deep-work', titleEn: 'Deep Work', titleBn: 'ডিপ ওয়ার্ক',
    author: 'Cal Newport', categoryId: 'habits', colorSeed: 3,
    descriptionBn: 'বিক্ষেপহীন গভীর মনোযোগে কাজ করার গুরুত্ব ও কৌশল নিয়ে লেখা।',
    lessonsBn: ['গভীর মনোযোগ এখন একটি দুর্লভ দক্ষতা।', 'কাজের জন্য নির্দিষ্ট সময় ঠিক করুন।', 'বিক্ষেপের উৎস কমান।'],
  ),
  Book(
    id: 'meditations', titleEn: 'Meditations', titleBn: 'মেডিটেশনস',
    author: 'Marcus Aurelius', categoryId: 'philosophy', colorSeed: 4,
    descriptionBn: 'রোমান সম্রাটের ব্যক্তিগত চিন্তা, যা স্টোইক দর্শনের একটি ভিত্তিমূলক গ্রন্থ। (প্রকাশিত অনুবাদের অধিকার আলাদাভাবে যাচাই করতে হবে।)',
    lessonsBn: ['যা নিয়ন্ত্রণে নেই তা মেনে নিন।', 'বর্তমান মুহূর্তে মনোযোগ দিন।', 'নিজের আচরণই নিজের দায়িত্ব।'],
  ),
  Book(
    id: 'art-of-war', titleEn: 'The Art of War', titleBn: 'দ্য আর্ট অব ওয়ার',
    author: 'Sun Tzu', categoryId: 'power_strategy', colorSeed: 5,
    descriptionBn: 'প্রাচীন চীনা সামরিক কৌশলের গ্রন্থ, যার ধারণা নেতৃত্ব ও পরিকল্পনায়ও ব্যবহৃত হয়।',
    lessonsBn: ['প্রস্তুতি জয়ের বড় অংশ।', 'নিজেকে ও প্রতিপক্ষকে বুঝুন।', 'সংঘাত এড়িয়ে লক্ষ্য অর্জন সবচেয়ে ভালো।'],
  ),
  Book(
    id: 'how-to-win-friends', titleEn: 'How to Win Friends and Influence People',
    titleBn: 'হাউ টু উইন ফ্রেন্ডস অ্যান্ড ইনফ্লুয়েন্স পিপল',
    author: 'Dale Carnegie', categoryId: 'communication', colorSeed: 6,
    descriptionBn: 'মানুষের সঙ্গে সম্পর্ক গড়া ও কার্যকর যোগাযোগের মৌলিক নীতি নিয়ে আলোচনা।',
    lessonsBn: ['অন্যের প্রতি আন্তরিক আগ্রহ দেখান।', 'সমালোচনার বদলে প্রশংসা করুন।', 'মন দিয়ে শুনুন।'],
  ),
];
