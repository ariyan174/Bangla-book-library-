import '../models/book.dart';

// SAMPLE DATA ONLY. Replaced by Firestore in Milestone 2.
const categories = <Category>[
  Category('personal_development', 'ব্যক্তিগত উন্নয়ন', 'Personal Development'),
  Category('psychology', 'মনোবিজ্ঞান ও মানব আচরণ', 'Psychology and Human Behavior'),
  Category('money', 'অর্থ ও ব্যক্তিগত অর্থায়ন', 'Money and Personal Finance'),
  Category('power_strategy', 'ক্ষমতা ও কৌশল', 'Power and Strategy'),
  Category('communication', 'যোগাযোগ ও প্ররোচনা', 'Communication and Persuasion'),
  Category('habits', 'অভ্যাস ও উৎপাদনশীলতা', 'Habits and Productivity'),
  Category('philosophy', 'দর্শন ও স্টোইসিজম', 'Philosophy and Stoicism'),
  Category('leadership', 'নেতৃত্ব ও ব্যবসা', 'Leadership and Business'),
  Category('learning', 'শেখা ও সমালোচনামূলক চিন্তা', 'Learning and Critical Thinking'),
  Category('biography', 'জীবনী ও স্মৃতিকথা', 'Biography and Memoir'),
];


// দক্ষতা অনুযায়ী বিভাগ (দ্বিতীয় শ্রেণিবিন্যাস)
const skills = <Category>[
  Category('productivity', 'উৎপাদনশীলতা', 'Productivity'),
  Category('communication_skill', 'যোগাযোগ', 'Communication'),
  Category('finance', 'ব্যক্তিগত অর্থ', 'Personal Finance'),
  Category('business', 'ব্যবসা', 'Business'),
  Category('discipline', 'শৃঙ্খলা', 'Discipline'),
  Category('thinking', 'চিন্তাভাবনা', 'Thinking'),
];

const sampleBooks = <Book>[
  Book(
    id: 'atomic-habits', titleEn: 'Atomic Habits', titleBn: 'অ্যাটমিক হ্যাবিটস',
    author: 'James Clear', categoryId: 'habits', colorSeed: 1, skillId: 'productivity',
    descriptionBn: 'ছোট ছোট অভ্যাস কীভাবে সময়ের সঙ্গে বড় পরিবর্তন আনে, তা নিয়ে একটি বই।',
    lessonsBn: ['ছোট পরিবর্তন জমতে জমতে বড় ফল দেয়।', 'লক্ষ্যের চেয়ে প্রক্রিয়ার ওপর মনোযোগ দিন।', 'ভালো অভ্যাস সহজ ও আকর্ষণীয় করুন।'],
  ),
  Book(
    id: 'psychology-of-money', titleEn: 'The Psychology of Money', titleBn: 'দ্য সাইকোলজি অব মানি',
    author: 'Morgan Housel', categoryId: 'money', colorSeed: 2, skillId: 'finance',
    descriptionBn: 'অর্থ নিয়ে আমাদের আচরণ ও মানসিকতা কীভাবে সিদ্ধান্তকে প্রভাবিত করে, তা আলোচনা করে।',
    lessonsBn: ['টাকা সামলানো জ্ঞানের চেয়ে আচরণের বিষয়।', 'ধৈর্য ও সময় সম্পদ গড়ার মূল শক্তি।', 'প্রয়োজনের বেশি ঝুঁকি এড়িয়ে চলুন।'],
  ),
  Book(
    id: 'deep-work', titleEn: 'Deep Work', titleBn: 'ডিপ ওয়ার্ক',
    author: 'Cal Newport', categoryId: 'habits', colorSeed: 3, skillId: 'productivity',
    descriptionBn: 'বিক্ষেপহীন গভীর মনোযোগে কাজ করার গুরুত্ব ও কৌশল নিয়ে লেখা।',
    lessonsBn: ['গভীর মনোযোগ এখন একটি দুর্লভ দক্ষতা।', 'কাজের জন্য নির্দিষ্ট সময় ঠিক করুন।', 'বিক্ষেপের উৎস কমান।'],
  ),
  Book(
    id: 'meditations', titleEn: 'Meditations', titleBn: 'মেডিটেশনস',
    author: 'Marcus Aurelius', categoryId: 'philosophy', colorSeed: 4, skillId: 'discipline',
    rights: RightsStatus.publicDomain,
    descriptionBn: 'রোমান সম্রাটের ব্যক্তিগত চিন্তা, যা স্টোইক দর্শনের একটি ভিত্তিমূলক গ্রন্থ। (প্রকাশিত অনুবাদের অধিকার আলাদাভাবে যাচাই করতে হবে।)',
    lessonsBn: ['যা নিয়ন্ত্রণে নেই তা মেনে নিন।', 'বর্তমান মুহূর্তে মনোযোগ দিন।', 'নিজের আচরণই নিজের দায়িত্ব।'],
  ),
  Book(
    id: 'art-of-war', titleEn: 'The Art of War', titleBn: 'দ্য আর্ট অব ওয়ার',
    author: 'Sun Tzu', categoryId: 'power_strategy', colorSeed: 5, skillId: 'business',
    rights: RightsStatus.publicDomain,
    descriptionBn: 'প্রাচীন চীনা সামরিক কৌশলের গ্রন্থ, যার ধারণা নেতৃত্ব ও পরিকল্পনায়ও ব্যবহৃত হয়।',
    lessonsBn: ['প্রস্তুতি জয়ের বড় অংশ।', 'নিজেকে ও প্রতিপক্ষকে বুঝুন।', 'সংঘাত এড়িয়ে লক্ষ্য অর্জন সবচেয়ে ভালো।'],
  ),
  Book(
    id: 'how-to-win-friends', titleEn: 'How to Win Friends and Influence People',
    titleBn: 'হাউ টু উইন ফ্রেন্ডস অ্যান্ড ইনফ্লুয়েন্স পিপল',
    author: 'Dale Carnegie', categoryId: 'communication', colorSeed: 6, skillId: 'communication_skill',
    descriptionBn: 'মানুষের সঙ্গে সম্পর্ক গড়া ও কার্যকর যোগাযোগের মৌলিক নীতি নিয়ে আলোচনা।',
    lessonsBn: ['অন্যের প্রতি আন্তরিক আগ্রহ দেখান।', 'সমালোচনার বদলে প্রশংসা করুন।', 'মন দিয়ে শুনুন।'],
  ),
  Book(
    id: 'art-of-laziness', titleEn: 'The Art of Laziness', titleBn: 'দ্য আর্ট অব লেজিনেস',
    author: 'Patrick King', categoryId: 'habits', colorSeed: 7, skillId: 'productivity',
    descriptionBn: 'টালবাহানা কাটিয়ে উৎপাদনশীলতা বাড়ানোর ব্যবহারিক ধারণা নিয়ে বই।',
    lessonsBn: ['কাজ ছোট করে শুরু করলে টালবাহানা কমে।', 'নিখুঁত হওয়ার চেষ্টায় অনেক সময় নষ্ট হয়।'],
  ),
  Book(
    id: 'do-it-today', titleEn: 'Do It Today', titleBn: 'ডু ইট টুডে',
    author: 'Darius Foroux', categoryId: 'habits', colorSeed: 8, skillId: 'productivity',
    descriptionBn: 'টালবাহানা কাটিয়ে আজই কাজ শুরু করার অভ্যাস গড়ার বই।',
    lessonsBn: ['সময় নষ্টের কারণগুলো চিনে নিন।', 'বড় কাজকে ছোট ধাপে ভেঙে আজই শুরু করুন।'],
  ),
  Book(
    id: 'finish-what-you-start', titleEn: 'Finish What You Start', titleBn: 'ফিনিশ হোয়াট ইউ স্টার্ট',
    author: 'Peter Hollins', categoryId: 'habits', colorSeed: 9, skillId: 'productivity',
    descriptionBn: 'শুরু করা কাজ শেষ করার মানসিকতা ও কৌশল নিয়ে বই।',
    lessonsBn: ['শেষ করার অভ্যাস শুরু করার চেয়ে বেশি মূল্যবান।', 'কাজ আধা ফেলে রাখার কারণ খুঁজে বের করুন।'],
  ),
  Book(
    id: '5am-club', titleEn: 'The 5 AM Club', titleBn: 'দ্য ৫ এএম ক্লাব',
    author: 'Robin Sharma', categoryId: 'habits', colorSeed: 10, skillId: 'productivity',
    descriptionBn: 'ভোরে ঘুম থেকে উঠে দিন গড়ার অভ্যাস নিয়ে একটি অনুপ্রেরণামূলক বই।',
    lessonsBn: ['সকালের প্রথম ঘণ্টা নিজের জন্য রাখুন।', 'লেখকের ২০/২০/২০ নিয়মে ব্যায়াম, ভাবনা ও শেখার সময় ভাগ করা হয়।'],
  ),
  Book(
    id: 'never-split-the-difference', titleEn: 'Never Split the Difference', titleBn: 'নেভার স্প্লিট দ্য ডিফারেন্স',
    author: 'Chris Voss', categoryId: 'communication', colorSeed: 11, skillId: 'communication_skill',
    descriptionBn: 'সাবেক এফবিআই আলোচকের দরকষাকষির কৌশল নিয়ে বই।',
    lessonsBn: ['সহানুভূতি দিয়ে অন্যের কথা বুঝুন।', 'প্রশ্ন করে আলোচনা নিজের দিকে ঘোরান।'],
  ),
  Book(
    id: 'crucial-conversations', titleEn: 'Crucial Conversations', titleBn: 'ক্রুশিয়াল কনভার্সেশনস',
    author: 'Kerry Patterson, Joseph Grenny, Ron McMillan, Al Switzler', categoryId: 'communication', colorSeed: 12, skillId: 'communication_skill',
    descriptionBn: 'উত্তেজনাপূর্ণ ও গুরুত্বপূর্ণ কথোপকথন সামলানোর কৌশল নিয়ে বই।',
    lessonsBn: ['কথা বলার আগে নিরাপদ পরিবেশ তৈরি করুন।', 'রাগ বা চাপের মধ্যেও লক্ষ্য মনে রাখুন।'],
  ),
  Book(
    id: 'how-to-talk-to-anyone', titleEn: 'How to Talk to Anyone', titleBn: 'হাউ টু টক টু এনিওয়ান',
    author: 'Leil Lowndes', categoryId: 'communication', colorSeed: 13, skillId: 'communication_skill',
    descriptionBn: 'মানুষের সঙ্গে সহজে আলাপ জমানোর ৯২টি ছোট কৌশলের বই।',
    lessonsBn: ['প্রথম কয়েক সেকেন্ডেই ভালো ছাপ ফেলা সম্ভব।', 'আগ্রহ দেখালে কথোপকথন সহজ হয়।'],
  ),
  Book(
    id: 'talk-like-ted', titleEn: 'Talk Like TED', titleBn: 'টক লাইক টেড',
    author: 'Carmine Gallo', categoryId: 'communication', colorSeed: 14, skillId: 'communication_skill',
    descriptionBn: 'বিখ্যাত টেড বক্তাদের ৯টি কৌশল নিয়ে বক্তৃতা দেওয়ার বই।',
    lessonsBn: ['গল্প দিয়ে বক্তব্য প্রাণবন্ত করুন।', 'একটি বার্তায় মনোযোগ রাখুন, বেশি কথা এড়ান।'],
  ),
  Book(
    id: 'influence', titleEn: 'Influence', titleBn: 'ইনফ্লুয়েন্স',
    author: 'Robert B. Cialdini', categoryId: 'communication', colorSeed: 15, skillId: 'communication_skill',
    descriptionBn: 'মানুষ কেন রাজি হয় তার মনস্তত্ত্ব ও ছয়টি নীতি নিয়ে বই।',
    lessonsBn: ['প্রতিদানের মনোভাব মানুষকে প্রভাবিত করে।', 'অন্যের আচরণ দেখে মানুষ সিদ্ধান্ত নেয়।'],
  ),
  Book(
    id: 'millionaire-fastlane', titleEn: 'The Millionaire Fastlane', titleBn: 'দ্য মিলিয়নেয়ার ফাস্টলেন',
    author: 'MJ DeMarco', categoryId: 'money', colorSeed: 16, skillId: 'finance',
    descriptionBn: 'চাকরির বাইরে ব্যবসা ও উদ্যোগের মাধ্যমে সম্পদ গড়ার ধারণা নিয়ে বই।',
    lessonsBn: ['সম্পদ গড়তে শুধু বেতনের ওপর নির্ভর না করার পরামর্শ।', 'মূল্য তৈরি করলে আয় বাড়ে।'],
  ),
  Book(
    id: 'just-keep-buying', titleEn: 'Just Keep Buying', titleBn: 'জাস্ট কিপ বায়িং',
    author: 'Nick Maggiulli', categoryId: 'money', colorSeed: 17, skillId: 'finance',
    descriptionBn: 'তথ্য ও উদাহরণ দিয়ে নিয়মিত সঞ্চয় ও বিনিয়োগের গুরুত্ব বোঝানো বই।',
    lessonsBn: ['নিয়মিত সঞ্চয় ও বিনিয়োগই মূল চাবিকাঠি।', 'আবেগে বিনিয়োগ ভাঙা ক্ষতিকর।'],
  ),
  Book(
    id: 'rich-dad-poor-dad', titleEn: 'Rich Dad Poor Dad', titleBn: 'রিচ ড্যাড পুওর ড্যাড',
    author: 'Robert T. Kiyosaki', categoryId: 'money', colorSeed: 18, skillId: 'finance',
    descriptionBn: 'সম্পদ ও দায়ের পার্থক্য এবং আর্থিক শিক্ষার গুরুত্ব নিয়ে বই। কিছু পরামর্শ নিয়ে সমালোচনাও আছে, তাই নিজে যাচাই করে নিন।',
    lessonsBn: ['সম্পদ ও দায়ের পার্থক্য বুঝুন।', 'আর্থিক শিক্ষা শেখা জরুরি।'],
  ),
  Book(
    id: 'total-money-makeover', titleEn: 'The Total Money Makeover', titleBn: 'দ্য টোটাল মানি মেকওভার',
    author: 'Dave Ramsey', categoryId: 'money', colorSeed: 19, skillId: 'finance',
    descriptionBn: 'ঋণ থেকে মুক্ত হয়ে ধাপে ধাপে আর্থিক স্থিতিশীলতার পরিকল্পনা নিয়ে বই।',
    lessonsBn: ['ছোট ঋণ আগে শোধ করে গতি আনুন।', 'জরুরি তহবিল তৈরি করুন।'],
  ),
  Book(
    id: 'i-will-teach-you-to-be-rich', titleEn: 'I Will Teach You to Be Rich', titleBn: 'আই উইল টিচ ইউ টু বি রিচ',
    author: 'Ramit Sethi', categoryId: 'money', colorSeed: 20, skillId: 'finance',
    descriptionBn: 'স্বয়ংক্রিয় সঞ্চয় ও বিনিয়োগের মাধ্যমে ৬ সপ্তাহে অর্থ গোছানোর পরিকল্পনা।',
    lessonsBn: ['সঞ্চয় ও বিনিয়োগ স্বয়ংক্রিয় করুন।', 'অকারণ অপরাধবোধ ছাড়াই পছন্দের খাতে খরচ করুন।'],
  ),
  Book(
    id: 'your-next-five-moves', titleEn: 'Your Next Five Moves', titleBn: 'ইওর নেক্সট ফাইভ মুভস',
    author: 'Patrick Bet-David', categoryId: 'leadership', colorSeed: 21, skillId: 'business',
    descriptionBn: 'দাবার মতো আগাম চাল ভেবে ব্যবসার কৌশল সাজানোর বই।',
    lessonsBn: ['পরের কয়েকটি ধাপ আগে থেকে ভাবুন।', 'নিজের সক্ষমতা ও সীমা জানুন।'],
  ),
  Book(
    id: 'good-to-great', titleEn: 'Good to Great', titleBn: 'গুড টু গ্রেট',
    author: 'Jim Collins', categoryId: 'leadership', colorSeed: 22, skillId: 'business',
    descriptionBn: 'সাধারণ প্রতিষ্ঠান কীভাবে দীর্ঘমেয়াদে অসাধারণ হয়, তা নিয়ে গবেষণাভিত্তিক বই।',
    lessonsBn: ['বিনয়ী ও দৃঢ় নেতৃত্ব গুরুত্বপূর্ণ।', 'প্রথমে সঠিক মানুষ বেছে নিন, তারপর কৌশল ঠিক করুন।'],
  ),
  Book(
    id: 'personal-mba', titleEn: 'The Personal MBA', titleBn: 'দ্য পার্সোনাল এমবিএ',
    author: 'Josh Kaufman', categoryId: 'leadership', colorSeed: 23, skillId: 'business',
    descriptionBn: 'ব্যবসার মৌলিক ধারণা নিজে শিখতে চাইলে সহজ ভাষায় লেখা বই।',
    lessonsBn: ['ব্যবসার মূল ধারণাগুলো নিজে শেখা সম্ভব।', 'মূল্য তৈরি ও বিনিময় ব্যবসার ভিত্তি।'],
  ),
  Book(
    id: 'hard-thing-about-hard-things', titleEn: 'The Hard Thing About Hard Things', titleBn: 'দ্য হার্ড থিং অ্যাবাউট হার্ড থিংস',
    author: 'Ben Horowitz', categoryId: 'leadership', colorSeed: 24, skillId: 'business',
    descriptionBn: 'ব্যবসা চালানোর কঠিন মুহূর্তে সিদ্ধান্ত নেওয়ার বাস্তব অভিজ্ঞতার বই।',
    lessonsBn: ['কঠিন সময়ে সৎ থাকা জরুরি।', 'সব সমস্যার সহজ উত্তর হয় না।'],
  ),
  Book(
    id: 'blue-ocean-strategy', titleEn: 'Blue Ocean Strategy', titleBn: 'ব্লু ওশান স্ট্র্যাটেজি',
    author: 'W. Chan Kim, Renée Mauborgne', categoryId: 'leadership', colorSeed: 25, skillId: 'business',
    descriptionBn: 'প্রতিযোগিতা এড়িয়ে নতুন বাজার তৈরির কৌশল নিয়ে বই।',
    lessonsBn: ['অন্যের সঙ্গে লড়ার বদলে নতুন বাজার তৈরি করুন।', 'গ্রাহকের নতুন মূল্য খুঁজুন।'],
  ),
  Book(
    id: 'built-to-last', titleEn: 'Built to Last', titleBn: 'বিল্ট টু লাস্ট',
    author: 'Jim Collins, Jerry I. Porras', categoryId: 'leadership', colorSeed: 26, skillId: 'business',
    descriptionBn: 'দীর্ঘস্থায়ী ও দূরদর্শী প্রতিষ্ঠানগুলোর অভ্যাস নিয়ে গবেষণাভিত্তিক বই।',
    lessonsBn: ['মূল্যবোধ ও উদ্দেশ্য প্রতিষ্ঠানের ভিত্তি।', 'দীর্ঘমেয়াদি ভাবনা রাখুন।'],
  ),
  Book(
    id: 'cant-hurt-me', titleEn: 'Can\'t Hurt Me', titleBn: 'ক্যান্ট হার্ট মি',
    author: 'David Goggins', categoryId: 'biography', colorSeed: 27, skillId: 'discipline',
    descriptionBn: 'কঠিন শৈশব পেরিয়ে মানসিক দৃঢ়তা গড়ার লেখকের নিজের জীবনের কাহিনি।',
    lessonsBn: ['মনে হলে আর পারছি না, তখনও সাধারণত আরও সামর্থ্য থাকে।', 'অস্বস্তি মেনে নিয়ে নিজেকে বদলান।'],
  ),
  Book(
    id: 'discipline-is-destiny', titleEn: 'Discipline Is Destiny', titleBn: 'ডিসিপ্লিন ইজ ডেস্টিনি',
    author: 'Ryan Holiday', categoryId: 'philosophy', colorSeed: 28, skillId: 'discipline',
    descriptionBn: 'স্টোইক দর্শনের আলোকে আত্মনিয়ন্ত্রণের গুরুত্ব নিয়ে বই।',
    lessonsBn: ['আত্মনিয়ন্ত্রণ চরিত্রের ভিত্তি।', 'ছোট প্রলোভন থেকে নিজেকে সামলান।'],
  ),
  Book(
    id: 'the-one-thing', titleEn: 'The One Thing', titleBn: 'দ্য ওয়ান থিং',
    author: 'Gary Keller, Jay Papasan', categoryId: 'habits', colorSeed: 29, skillId: 'discipline',
    descriptionBn: 'একটি সবচেয়ে গুরুত্বপূর্ণ কাজে মনোযোগ দেওয়ার ধারণা নিয়ে বই।',
    lessonsBn: ['একসঙ্গে অনেক কাজের বদলে একটি মূল কাজে মন দিন।', 'প্রতিদিনের গুরুত্বপূর্ণ কাজ আগে করুন।'],
  ),
  Book(
    id: '365-days-of-discipline', titleEn: '365 Days of Discipline', titleBn: '৩৬৫ ডেজ অব ডিসিপ্লিন',
    author: 'Martin Meadows', categoryId: 'personal_development', colorSeed: 30, skillId: 'discipline',
    descriptionBn: 'প্রতিদিনের ছোট অভ্যাস দিয়ে শৃঙ্খলা গড়ার ধারণা নিয়ে বই।',
    lessonsBn: ['শৃঙ্খলা ছোট ছোট নিয়মিত পদক্ষেপে গড়ে ওঠে।', 'অজুহাত চিনে সরিয়ে দিন।'],
  ),
  Book(
    id: 'extreme-ownership', titleEn: 'Extreme Ownership', titleBn: 'এক্সট্রিম ওনারশিপ',
    author: 'Jocko Willink, Leif Babin', categoryId: 'leadership', colorSeed: 31, skillId: 'discipline',
    descriptionBn: 'সাবেক নেভি সিলদের অভিজ্ঞতা থেকে নিজের দায় নিয়ে নেতৃত্ব দেওয়ার বই।',
    lessonsBn: ['ফলাফলের দায় নিজে নিন।', 'ভালো নেতা দলকে পরিষ্কার লক্ষ্য দেন।'],
  ),
  Book(
    id: 'obstacle-is-the-way', titleEn: 'The Obstacle Is the Way', titleBn: 'দ্য অবস্ট্যাকল ইজ দ্য ওয়ে',
    author: 'Ryan Holiday', categoryId: 'philosophy', colorSeed: 32, skillId: 'discipline',
    descriptionBn: 'স্টোইক দর্শনের আলোকে বাধাকে সুযোগে বদলানোর বই।',
    lessonsBn: ['বাধা সামনে এলে দৃষ্টিভঙ্গি বদলান।', 'যা নিয়ন্ত্রণে আছে তাতে কাজ করুন।'],
  ),
  Book(
    id: 'think-again', titleEn: 'Think Again', titleBn: 'থিংক এগেইন',
    author: 'Adam Grant', categoryId: 'learning', colorSeed: 33, skillId: 'thinking',
    descriptionBn: 'নিজের মত পুনর্বিবেচনা করার ও ভুল মেনে নেওয়ার দক্ষতা নিয়ে বই।',
    lessonsBn: ['নিজের ধারণা বারবার যাচাই করুন।', 'বিনয়ী হয়ে নতুন তথ্য গ্রহণ করুন।'],
  ),
  Book(
    id: 'mindset', titleEn: 'Mindset', titleBn: 'মাইন্ডসেট',
    author: 'Carol S. Dweck', categoryId: 'personal_development', colorSeed: 34, skillId: 'thinking',
    descriptionBn: 'স্থির ও বর্ধনশীল মানসিকতার পার্থক্য নিয়ে বই।',
    lessonsBn: ['চেষ্টা ও শেখার মাধ্যমে দক্ষতা বাড়ে, এই বিশ্বাস রাখুন।', 'ব্যর্থতাকে শেখার সুযোগ ভাবুন।'],
  ),
  Book(
    id: 'how-to-think-more-effectively', titleEn: 'How to Think More Effectively', titleBn: 'হাউ টু থিংক মোর ইফেক্টিভলি',
    author: 'The School of Life', categoryId: 'learning', colorSeed: 35, skillId: 'thinking',
    descriptionBn: 'দক্ষতা, অন্তর্দৃষ্টি ও সৃজনশীলতা বাড়ানোর চিন্তার গাইড।',
    lessonsBn: ['নিজের চিন্তার ধরন নজরে রাখুন।', 'শান্তভাবে ভাবার জন্য সময় রাখুন।'],
  ),
  Book(
    id: 'superthinking', titleEn: 'Super Thinking', titleBn: 'সুপারথিংকিং',
    author: 'Gabriel Weinberg, Lauren McCann', categoryId: 'learning', colorSeed: 36, skillId: 'thinking',
    descriptionBn: 'বিভিন্ন বিষয় থেকে মানসিক মডেল শিখে সিদ্ধান্তের মান বাড়ানোর বই।',
    lessonsBn: ['অনেক মানসিক মডেল জানলে সমস্যা ভালো বোঝা যায়।', 'একই সমস্যাকে নানা দিক থেকে দেখুন।'],
  ),
  Book(
    id: 'predictably-irrational', titleEn: 'Predictably Irrational', titleBn: 'প্রেডিক্টেবলি ইরেশনাল',
    author: 'Dan Ariely', categoryId: 'psychology', colorSeed: 37, skillId: 'thinking',
    descriptionBn: 'মানুষের অযৌক্তিক সিদ্ধান্তের ছকবাঁধা ধরন আচরণগত অর্থনীতির আলোকে ব্যাখ্যা করা বই।',
    lessonsBn: ['আমরা সিদ্ধান্তে প্রায়ই প্রভাবিত হই, তা খেয়াল রাখুন।', 'তুলনা ও প্রসঙ্গ আমাদের পছন্দ বদলে দেয়।'],
  ),
];
