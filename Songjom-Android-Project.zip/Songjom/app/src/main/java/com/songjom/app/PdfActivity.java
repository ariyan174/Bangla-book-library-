package com.songjom.app;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.util.LruCache;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * In-app PDF reader. The first time a book is opened it is downloaded from its direct PDF link
 * into the app's private storage; after that it opens offline. Reading never leaves the app.
 */
public class PdfActivity extends Activity {
    private String url, title;
    private File file;

    private PdfRenderer renderer;
    private ParcelFileDescriptor pfd;
    private int[] pw, ph;
    private int screenW;
    private volatile boolean closed = false;
    private final Object lock = new Object();
    private final ExecutorService renderEx = Executors.newSingleThreadExecutor();
    private LruCache<Integer, Bitmap> cache;

    private TextView header;
    private ListView list;
    private LinearLayout statusBox;
    private TextView statusTx;
    private ProgressBar bar;
    private Button retry;
    private int tx, mu;

    /** Where a book's PDF is stored in the app's private folder. */
    public static File fileFor(Context c, String url) {
        File d = new File(c.getFilesDir(), "books");
        d.mkdirs();
        return new File(d, Integer.toHexString(url.hashCode()) + "_" + url.length() + ".pdf");
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        url = getIntent().getStringExtra("url");
        title = getIntent().getStringExtra("title");
        if (url == null || url.length() == 0) { finish(); return; }
        if (title == null) title = "বই";
        file = fileFor(this, url);

        boolean dark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        int bg = Color.parseColor(dark ? "#0E1612" : "#F4F7F5");
        tx = Color.parseColor(dark ? "#E8F1EC" : "#14261D");
        mu = Color.parseColor(dark ? "#98ACA1" : "#5D6F65");
        getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(bg));
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        if (!dark) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
        screenW = getResources().getDisplayMetrics().widthPixels;
        int mem = (int) (Runtime.getRuntime().maxMemory() / 1024 / 6);
        cache = new LruCache<Integer, Bitmap>(Math.max(8192, mem)) {
            @Override protected int sizeOf(Integer k, Bitmap v) { return v.getByteCount() / 1024; }
        };

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);

        header = new TextView(this);
        header.setText(title);
        header.setTextColor(tx);
        header.setTextSize(17);
        header.setTypeface(null, android.graphics.Typeface.BOLD);
        header.setPadding(dp(16), dp(14) + statusBarPad(), dp(16), dp(12));
        root.addView(header, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        FrameLayout body = new FrameLayout(this);
        list = new ListView(this);
        list.setDivider(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        list.setDividerHeight(dp(6));
        list.setVerticalScrollBarEnabled(true);
        list.setVisibility(View.GONE);
        body.addView(list, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        statusBox = new LinearLayout(this);
        statusBox.setOrientation(LinearLayout.VERTICAL);
        statusBox.setGravity(Gravity.CENTER);
        statusBox.setPadding(dp(28), dp(28), dp(28), dp(28));
        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        bar.setIndeterminate(true);
        statusBox.addView(bar, new LinearLayout.LayoutParams(dp(240), LinearLayout.LayoutParams.WRAP_CONTENT));
        statusTx = new TextView(this);
        statusTx.setTextColor(mu);
        statusTx.setTextSize(15);
        statusTx.setGravity(Gravity.CENTER);
        statusTx.setPadding(0, dp(14), 0, dp(14));
        statusBox.addView(statusTx);
        retry = new Button(this);
        retry.setText("আবার চেষ্টা করুন");
        retry.setAllCaps(false);
        retry.setTextColor(Color.WHITE);
        retry.setBackgroundColor(Color.parseColor("#1F8A5B"));
        retry.setPadding(dp(24), dp(10), dp(24), dp(10));
        retry.setVisibility(View.GONE);
        retry.setOnClickListener(v -> { try { file.delete(); } catch (Throwable ignored) { } download(); });
        statusBox.addView(retry);
        body.addView(statusBox, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        root.addView(body, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        if (file.exists() && file.length() > 0) prepare(); else download();
    }

    private int statusBarPad() {
        try {
            int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
            return id > 0 ? getResources().getDimensionPixelSize(id) : 0;
        } catch (Throwable t) { return 0; }
    }

    // ---------- UI state helpers ----------
    private void showBusy(String msg) {
        list.setVisibility(View.GONE);
        statusBox.setVisibility(View.VISIBLE);
        bar.setVisibility(View.VISIBLE);
        bar.setIndeterminate(true);
        retry.setVisibility(View.GONE);
        statusTx.setText(msg);
    }

    private void showError(String msg) {
        list.setVisibility(View.GONE);
        statusBox.setVisibility(View.VISIBLE);
        bar.setVisibility(View.GONE);
        retry.setVisibility(View.VISIBLE);
        statusTx.setText(msg);
    }

    private void setPct(int pct) {
        bar.setIndeterminate(false);
        bar.setProgress(pct);
        statusTx.setText("ডাউনলোড হচ্ছে… " + pct + "%");
    }

    // ---------- download ----------
    private void download() {
        showBusy("ইন্টারনেট থেকে বই ডাউনলোড হচ্ছে…");
        new Thread(() -> {
            File part = new File(file.getParentFile(), file.getName() + ".part");
            try {
                String cur = url;
                HttpURLConnection c = null;
                for (int hop = 0; hop < 6; hop++) {
                    c = (HttpURLConnection) new URL(cur).openConnection();
                    c.setConnectTimeout(15000);
                    c.setReadTimeout(30000);
                    c.setInstanceFollowRedirects(false);
                    c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) Songjom");
                    int code = c.getResponseCode();
                    if (code >= 300 && code < 400) {
                        String loc = c.getHeaderField("Location");
                        c.disconnect();
                        c = null;
                        if (loc == null) throw new Exception("bad redirect");
                        cur = new URL(new URL(cur), loc).toString();
                        continue;
                    }
                    if (code != 200) throw new Exception("HTTP " + code);
                    break;
                }
                if (c == null) throw new Exception("too many redirects");
                final long total = c.getContentLength();
                long got = 0;
                int last = -1;
                try (InputStream in = c.getInputStream(); OutputStream out = new FileOutputStream(part)) {
                    byte[] buf = new byte[32768];
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        out.write(buf, 0, n);
                        got += n;
                        if (total > 0) {
                            final int pct = (int) (got * 100 / total);
                            if (pct != last) { last = pct; runOnUiThread(() -> setPct(pct)); }
                        }
                    }
                }
                c.disconnect();
                // must really be a PDF (a direct link, not a web page)
                byte[] head = new byte[4];
                try (InputStream in = new FileInputStream(part)) {
                    if (in.read(head) < 4 || head[0] != '%' || head[1] != 'P' || head[2] != 'D' || head[3] != 'F') {
                        throw new Exception("not a pdf");
                    }
                }
                if (!part.renameTo(file)) throw new Exception("rename failed");
                runOnUiThread(this::prepare);
            } catch (Throwable e) {
                try { part.delete(); } catch (Throwable ignored) { }
                final boolean notPdf = "not a pdf".equals(e.getMessage());
                runOnUiThread(() -> showError(notPdf
                        ? "এই লিংকটি সরাসরি PDF ফাইল নয়।"
                        : "ডাউনলোড হয়নি। ইন্টারনেট ঠিক আছে কিনা দেখে আবার চেষ্টা করুন।"));
            }
        }).start();
    }

    // ---------- open & render ----------
    private void prepare() {
        showBusy("বই খোলা হচ্ছে…");
        new Thread(() -> {
            try {
                pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
                renderer = new PdfRenderer(pfd);
                int n = renderer.getPageCount();
                pw = new int[n];
                ph = new int[n];
                for (int i = 0; i < n; i++) {
                    PdfRenderer.Page p = renderer.openPage(i);
                    pw[i] = Math.max(1, p.getWidth());
                    ph[i] = Math.max(1, p.getHeight());
                    p.close();
                }
                runOnUiThread(this::showPages);
            } catch (Throwable e) {
                try { file.delete(); } catch (Throwable ignored) { }
                runOnUiThread(() -> showError("বইটি খোলা যায়নি। ফাইলটি নষ্ট হতে পারে, আবার ডাউনলোড করুন।"));
            }
        }).start();
    }

    private void showPages() {
        if (closed) return;
        final int total = pw.length;
        list.setAdapter(new BaseAdapter() {
            @Override public int getCount() { return total; }
            @Override public Object getItem(int i) { return i; }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(int pos, View cv, ViewGroup parent) {
                ImageView iv;
                if (cv instanceof ImageView) {
                    iv = (ImageView) cv;
                } else {
                    iv = new ImageView(PdfActivity.this);
                    iv.setScaleType(ImageView.ScaleType.FIT_XY);
                    iv.setBackgroundColor(Color.WHITE);
                }
                int h = (int) ((long) screenW * ph[pos] / pw[pos]);
                iv.setLayoutParams(new AbsListView.LayoutParams(screenW, h));
                iv.setTag(pos);
                Bitmap bm = cache.get(pos);
                if (bm != null) {
                    iv.setImageBitmap(bm);
                } else {
                    iv.setImageDrawable(null);
                    render(pos, iv, screenW, h);
                }
                return iv;
            }
        });
        list.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override public void onScrollStateChanged(AbsListView v, int s) { }
            @Override public void onScroll(AbsListView v, int first, int vis, int cnt) {
                header.setText(title + "   (" + (first + 1) + "/" + total + ")");
            }
        });
        statusBox.setVisibility(View.GONE);
        list.setVisibility(View.VISIBLE);
        int saved = getSharedPreferences("books", MODE_PRIVATE).getInt("pos_" + file.getName(), 0);
        if (saved > 0 && saved < total) list.setSelection(saved);
        header.setText(title + "   (" + (saved + 1) + "/" + total + ")");
    }

    private void render(final int pos, final ImageView iv, final int w, final int h) {
        try {
            renderEx.execute(() -> {
                if (closed) return;
                Bitmap bmp = cache.get(pos);
                if (bmp == null) {
                    try {
                        bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                        bmp.eraseColor(Color.WHITE);
                        synchronized (lock) {
                            if (closed) return;
                            PdfRenderer.Page p = renderer.openPage(pos);
                            p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                            p.close();
                        }
                        cache.put(pos, bmp);
                    } catch (Throwable t) {
                        return;
                    }
                }
                final Bitmap fb = bmp;
                runOnUiThread(() -> {
                    Object tg = iv.getTag();
                    if (tg instanceof Integer && ((Integer) tg) == pos) iv.setImageBitmap(fb);
                });
            });
        } catch (Throwable ignored) { }
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            if (list != null && file != null && list.getVisibility() == View.VISIBLE) {
                getSharedPreferences("books", MODE_PRIVATE).edit()
                        .putInt("pos_" + file.getName(), list.getFirstVisiblePosition()).apply();
            }
        } catch (Throwable ignored) { }
    }

    @Override
    protected void onDestroy() {
        closed = true;
        try { renderEx.shutdownNow(); } catch (Throwable ignored) { }
        synchronized (lock) {
            try { if (renderer != null) renderer.close(); } catch (Throwable ignored) { }
            try { if (pfd != null) pfd.close(); } catch (Throwable ignored) { }
            renderer = null;
        }
        super.onDestroy();
    }
}
