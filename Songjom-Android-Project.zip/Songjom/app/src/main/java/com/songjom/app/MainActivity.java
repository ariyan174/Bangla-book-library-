package com.songjom.app;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.RequestConfiguration;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

public class MainActivity extends Activity {
    private WebView web;

    // ---- AdMob (Google official TEST banner unit; replace with your own unit ID later) ----
    private static final String BANNER_UNIT_ID = "ca-app-pub-3940256099942544/6300978111";
    private AdView ad;
    private boolean adWanted = false, adLoaded = false, adRequested = false;

    // ---- Full-screen (interstitial) ad: shown when the user presses Back from a feature page ----
    // Google's official TEST interstitial unit; replace with your own unit ID later.
    private static final String INTER_UNIT_ID = "ca-app-pub-3940256099942544/1033173712";
    private static final long INTER_GAP_MS = 30_000L;   // minimum gap between two full-screen ads
    private InterstitialAd inter;
    private boolean interLoading = false;
    private long lastInterMs = 0L;

    // ---- Internet-required gate ----
    private LinearLayout offlineView;
    private ConnectivityManager.NetworkCallback netCb;

    /** Lets the page follow the phone's light/dark setting. */
    private class Bridge {
        @JavascriptInterface
        public boolean isDark() { return nightMode(); }

        /** App version name (from build.gradle), shown in the side menu. */
        @JavascriptInterface
        public String appVersion() {
            try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
            catch (Throwable e) { return ""; }
        }

        /** True when the user has allowed "Display over other apps". */
        @JavascriptInterface
        public boolean canOverlay() {
            try { return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(MainActivity.this); }
            catch (Exception e) { return false; }
        }

        /** Opens the system screen where the user can allow "Display over other apps". */
        @JavascriptInterface
        public void requestOverlay() {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + getPackageName()));
                    startActivity(i);
                } catch (Exception ignored) { }
            });
        }

        /** SOS countdown started: full-screen overlay (if allowed). endMs = end time in ms. */
        @JavascriptInterface
        public void lock(String endMs) {
            final String e = endMs;
            runOnUiThread(() -> {
                try {
                    if (canOverlay()) {
                        Intent i = new Intent(MainActivity.this, SosLockService.class);
                        i.putExtra(SosLockService.EXTRA_END, Long.parseLong(e));
                        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
                    }
                } catch (Throwable t) {
                    getSharedPreferences(SosLockService.PREFS, MODE_PRIVATE).edit()
                        .putString(SosLockService.STATUS, "সার্ভিস শুরু হয়নি: " + t.getClass().getSimpleName() + " " + t.getMessage()).apply();
                }
                // No screen pinning any more: the full-screen overlay does the locking, so the
                // "App is pinned" prompt never appears.
            });
        }

        /** Short 10-second test of the full-screen lock (no SOS used). */
        @JavascriptInterface
        public void testLock() {
            runOnUiThread(() -> {
                try {
                    if (!canOverlay()) return;
                    Intent i = new Intent(MainActivity.this, SosLockService.class);
                    i.putExtra(SosLockService.EXTRA_END, System.currentTimeMillis() + 10_000L);
                    i.putExtra(SosLockService.EXTRA_DUR, 10_000L);
                    if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
                } catch (Throwable e) {
                    getSharedPreferences(SosLockService.PREFS, MODE_PRIVATE).edit()
                        .putString(SosLockService.STATUS, "সার্ভিস শুরু হয়নি: " + e.getClass().getSimpleName() + " " + e.getMessage()).apply();
                }
            });
        }

        /** Last status text written by the lock service (for on-screen diagnosis). */
        @JavascriptInterface
        public String lockStatus() {
            return getSharedPreferences(SosLockService.PREFS, MODE_PRIVATE).getString(SosLockService.STATUS, "এখনও চালানো হয়নি");
        }

        /** Opens a web link (Facebook page/group) in the Facebook app or the browser. */
        @JavascriptInterface
        public void openUrl(String url) {
            final String u = url;
            runOnUiThread(() -> {
                try {
                    if (u == null || !(u.startsWith("https://") || u.startsWith("http://"))) return;
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u)));
                } catch (Throwable t) {
                    android.widget.Toast.makeText(MainActivity.this, "লিংক খোলা যায়নি", android.widget.Toast.LENGTH_SHORT).show();
                }
            });
        }

        /** Opens the mail app with the developer's address filled in. */
        @JavascriptInterface
        public void openMail(String email) {
            final String m = email;
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + m));
                    i.putExtra(Intent.EXTRA_SUBJECT, "সংযম অ্যাপ");
                    startActivity(i);
                } catch (Throwable t) {
                    android.widget.Toast.makeText(MainActivity.this, "ইমেইল অ্যাপ পাওয়া যায়নি, ঠিকানাটি কপি করে নিন", android.widget.Toast.LENGTH_LONG).show();
                }
            });
        }

        /** True when this book's PDF is already downloaded. */
        @JavascriptInterface
        public boolean bookHas(String url) {
            try {
                java.io.File f = PdfActivity.fileFor(MainActivity.this, url);
                return f.exists() && f.length() > 0;
            } catch (Throwable t) { return false; }
        }

        /** Opens the in-app PDF reader (downloads the book first if needed). */
        @JavascriptInterface
        public void openBook(String url, String title) {
            final String u = url, t = title;
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(MainActivity.this, PdfActivity.class);
                    i.putExtra("url", u);
                    i.putExtra("title", t);
                    startActivity(i);
                } catch (Throwable ignored) { }
            });
        }

        /** Keeps the screen on (used during SOS and on its finish screen) so the phone never switches off by itself. */
        @JavascriptInterface
        public void keepAwake(boolean on) {
            final boolean o = on;
            runOnUiThread(() -> {
                try {
                    if (o) getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    else getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                } catch (Throwable ignored) { }
            });
        }

        /** Show/hide the bottom banner (the page hides it only while the SOS screen is open). */
        @JavascriptInterface
        public void showAds(boolean show) {
            final boolean s = show;
            runOnUiThread(() -> setAdsWanted(s));
        }

        /** User pressed Back from a feature page: maybe show a full-screen ad. */
        @JavascriptInterface
        public void backAd() {
            runOnUiThread(() -> showInter());
        }

        @JavascriptInterface
        public void unlock() {
            runOnUiThread(() -> {
                try { stopService(new Intent(MainActivity.this, SosLockService.class)); } catch (Exception ignored) { }
                try { stopLockTask(); } catch (Exception ignored) { }
            });
        }
    }

    private boolean nightMode() {
        int m = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return m == Configuration.UI_MODE_NIGHT_YES;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        boolean dark = nightMode();
        int bg = Color.parseColor(dark ? "#0E1612" : "#F4F7F5");
        getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(bg));
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        if (!dark && android.os.Build.VERSION.SDK_INT >= 26) {
            getWindow().getDecorView().setSystemUiVisibility(
                android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                | android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }

        web = new WebView(this);
        web.setBackgroundColor(bg);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);
        root.addView(web, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        setupAds(root);
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(bg);
        frame.addView(root, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        buildOfflineView(frame, bg, dark);
        setContentView(frame);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // localStorage = saved progress
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setTextZoom(100);
        web.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        web.addJavascriptInterface(new Bridge(), "NativeApp");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return true; // never navigate away; everything is local
            }
        });

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl("file:///android_asset/index.html");
        }
        checkNet(true);
        registerNetCallback();
    }

    // ================= Internet-required gate =================
    private boolean hasInternet() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            if (cm == null) return false;
            Network n = cm.getActiveNetwork();
            if (n == null) return false;
            NetworkCapabilities c = cm.getNetworkCapabilities(n);
            return c != null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
        } catch (Throwable t) {
            return true;   // never lock the user out because of a check failure
        }
    }

    /** allowShow=false: only hide the gate (used by the network callback, so the app is never blocked mid-use). */
    private void checkNet(boolean allowShow) {
        if (offlineView == null) return;
        boolean ok = hasInternet();
        if (ok) {
            offlineView.setVisibility(View.GONE);
        } else if (allowShow) {
            offlineView.setVisibility(View.VISIBLE);
        }
    }

    private void registerNetCallback() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            if (cm == null) return;
            netCb = new ConnectivityManager.NetworkCallback() {
                @Override public void onAvailable(Network network) { runOnUiThread(() -> checkNet(false)); }
                @Override public void onCapabilitiesChanged(Network network, NetworkCapabilities caps) {
                    runOnUiThread(() -> checkNet(false));
                }
            };
            cm.registerDefaultNetworkCallback(netCb);
        } catch (Throwable ignored) { netCb = null; }
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void buildOfflineView(FrameLayout frame, int bg, boolean dark) {
        int tx = Color.parseColor(dark ? "#E8F1EC" : "#14261D");
        int mu = Color.parseColor(dark ? "#98ACA1" : "#5D6F65");
        offlineView = new LinearLayout(this);
        offlineView.setOrientation(LinearLayout.VERTICAL);
        offlineView.setGravity(Gravity.CENTER);
        offlineView.setBackgroundColor(bg);
        offlineView.setPadding(dp(28), dp(28), dp(28), dp(28));
        offlineView.setClickable(true);          // swallow touches so nothing behind can be used
        offlineView.setVisibility(View.GONE);

        TextView ic = new TextView(this);
        ic.setText("📡");
        ic.setTextSize(52);
        ic.setGravity(Gravity.CENTER);
        offlineView.addView(ic);

        TextView t = new TextView(this);
        t.setText("ইন্টারনেট সংযোগ নেই");
        t.setTextColor(tx);
        t.setTextSize(21);
        t.setTypeface(null, android.graphics.Typeface.BOLD);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(12), 0, dp(8));
        offlineView.addView(t);

        TextView m = new TextView(this);
        m.setText("সংযম অ্যাপ চালাতে ইন্টারনেট (ওয়াইফাই বা মোবাইল ডেটা) চালু থাকতে হবে। ইন্টারনেট চালু করে নিচের বাটনে চাপ দিন।");
        m.setTextColor(mu);
        m.setTextSize(15);
        m.setGravity(Gravity.CENTER);
        m.setPadding(0, 0, 0, dp(22));
        offlineView.addView(m);

        Button b = new Button(this);
        b.setText("আবার চেষ্টা করুন");
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setBackgroundColor(Color.parseColor("#1F8A5B"));
        b.setPadding(dp(28), dp(12), dp(28), dp(12));
        b.setOnClickListener(v -> checkNet(true));
        offlineView.addView(b, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        frame.addView(offlineView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
    }

    // ================= Interstitial (full-screen) ad =================
    private void loadInter() {
        if (inter != null || interLoading) return;
        interLoading = true;
        try {
            InterstitialAd.load(this, INTER_UNIT_ID, new AdRequest.Builder().build(),
                    new InterstitialAdLoadCallback() {
                        @Override
                        public void onAdLoaded(InterstitialAd ad) {
                            inter = ad;
                            interLoading = false;
                        }

                        @Override
                        public void onAdFailedToLoad(LoadAdError error) {
                            inter = null;
                            interLoading = false;
                        }
                    });
        } catch (Throwable t) {
            interLoading = false;
        }
    }

    private void showInter() {
        try {
            if (inter == null) { loadInter(); return; }
            long now = System.currentTimeMillis();
            if (now - lastInterMs < INTER_GAP_MS) return;
            final InterstitialAd a = inter;
            inter = null;
            a.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override public void onAdDismissedFullScreenContent() { loadInter(); }
                @Override public void onAdFailedToShowFullScreenContent(AdError e) { loadInter(); }
            });
            lastInterMs = now;
            a.show(this);
        } catch (Throwable ignored) { }
    }

    /** Adds a hidden banner at the bottom. Any failure (no internet, no Play services) just leaves it hidden. */
    private void setupAds(LinearLayout root) {
        try {
            MobileAds.setRequestConfiguration(new RequestConfiguration.Builder()
                    .setMaxAdContentRating(RequestConfiguration.MAX_AD_CONTENT_RATING_G)
                    .build());
            final android.content.Context appCtx = getApplicationContext();
            new Thread(() -> {
                try { MobileAds.initialize(appCtx, status -> runOnUiThread(this::loadInter)); } catch (Throwable ignored) { }
            }).start();

            ad = new AdView(this);
            ad.setAdSize(AdSize.BANNER);
            ad.setAdUnitId(BANNER_UNIT_ID);
            ad.setVisibility(View.GONE);
            ad.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                    adLoaded = true;
                    applyAdVisibility();
                }

                @Override
                public void onAdFailedToLoad(LoadAdError error) {
                    adLoaded = false;
                    adRequested = false;   // try again next time the page is shown
                    applyAdVisibility();
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.gravity = Gravity.CENTER_HORIZONTAL;
            root.addView(ad, lp);
        } catch (Throwable t) {
            ad = null;
        }
    }

    private void applyAdVisibility() {
        if (ad == null) return;
        ad.setVisibility(adWanted && adLoaded ? View.VISIBLE : View.GONE);
    }

    private void setAdsWanted(boolean want) {
        adWanted = want;
        if (ad == null) return;
        try {
            if (want && !adRequested) {
                adRequested = true;
                ad.loadAd(new AdRequest.Builder().build());
            }
        } catch (Throwable ignored) { }
        applyAdVisibility();
    }

    /** Coming back from the SOS lock screen: keep the screen awake for a short while. */
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && intent.getBooleanExtra("from_sos", false)) {
            try {
                getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                web.postDelayed(() -> {
                    try { getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); } catch (Throwable ignored) { }
                }, 30_000L);
            } catch (Throwable ignored) { }
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    public void onBackPressed() {
        if (offlineView != null && offlineView.getVisibility() == View.VISIBLE) { finish(); return; }
        // Let the page handle "back": close SOS-block, popup, drawer, or return to Home.
        web.evaluateJavascript(
            "(function(){try{return window.goBack?goBack():0}catch(e){return 0}})()",
            value -> { if (!"1".equals(value)) finish(); });
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.onPause();
        try { if (ad != null) ad.pause(); } catch (Throwable ignored) { }
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
        checkNet(true);
        try { if (ad != null) ad.resume(); } catch (Throwable ignored) { }
    }

    @Override
    protected void onDestroy() {
        try {
            if (netCb != null) {
                ((ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE)).unregisterNetworkCallback(netCb);
            }
        } catch (Throwable ignored) { }
        try { if (ad != null) ad.destroy(); } catch (Throwable ignored) { }
        super.onDestroy();
    }
}
