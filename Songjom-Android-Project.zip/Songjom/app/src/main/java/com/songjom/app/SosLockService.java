package com.songjom.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.ContextThemeWrapper;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

/**
 * Full-screen "SOS lock": while the 10-minute countdown runs, a full-screen overlay
 * (drawn over every other app and the home screen) shows the countdown and blocks all touches.
 * Needs the user to allow "Display over other apps" once.
 */
public class SosLockService extends Service {
    public static final String EXTRA_END = "end";
    public static final String EXTRA_DUR = "dur";
    public static final String STATUS = "status";
    public static final String PREFS = "sos_lock";
    private static final String CHANNEL = "sos_lock";

    private long dur = 600_000L;
    private final Handler main = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private FrameLayout root;
    private WebView web;
    private boolean overlayShown = false;

    private class Bridge {
        @JavascriptInterface
        public boolean isDark() {
            int m = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
            return m == Configuration.UI_MODE_NIGHT_YES;
        }

        /** Countdown finished and the user tapped the button: remove overlay and open the app. */
        @JavascriptInterface
        public void sosFinish() {
            main.post(() -> {
                // 1) keep the screen awake so it cannot switch off the moment the lock goes away
                wakeBriefly();
                // 2) open the app FIRST, while the overlay is still on screen
                try {
                    Intent i = new Intent(SosLockService.this, MainActivity.class);
                    i.putExtra("from_sos", true);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                            | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    startActivity(i);
                } catch (Exception ignored) { }
                // 3) only then take the overlay down
                main.postDelayed(() -> {
                    removeOverlay();
                    try { stopForeground(true); } catch (Throwable ignored) { }
                    stopSelf();
                }, 600L);
            });
        }
    }

    private void status(String v) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(STATUS, v).apply();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        long end = intent != null ? intent.getLongExtra(EXTRA_END, 0L) : 0L;
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (intent != null) dur = intent.getLongExtra(EXTRA_DUR, 600_000L);
        status("সার্ভিস চালু হয়েছে");
        if (end > 0) sp.edit().putLong(EXTRA_END, end).apply(); else end = sp.getLong(EXTRA_END, 0L);

        startAsForeground();

        if (end <= 0 || end < System.currentTimeMillis() - 60_000L) {   // nothing to lock
            stopSelf();
            return START_NOT_STICKY;
        }
        try {
            showOverlay(end);
            status("ওভারলে বসানো হয়েছে ✅");
        } catch (Throwable e) {      // no permission or window refused
            status("ওভারলে বসেনি: " + e.getClass().getSimpleName() + " " + e.getMessage());
            removeOverlay();
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void startAsForeground() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= 26 && nm != null) {
                nm.createNotificationChannel(new NotificationChannel(CHANNEL, "SOS", NotificationManager.IMPORTANCE_LOW));
            }
            Notification.Builder b = Build.VERSION.SDK_INT >= 26
                    ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
            b.setSmallIcon(android.R.drawable.ic_lock_lock)
                    .setContentTitle("সংযম – SOS চলছে")
                    .setContentText("১০ মিনিট টিকে থাকুন, ইনশাআল্লাহ আপনি পারবেন।")
                    .setOngoing(true);
            Notification n = b.build();
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            } else {
                startForeground(7, n);
            }
        } catch (Throwable e) {
            status("ফোরগ্রাউন্ড সার্ভিস ব্যর্থ: " + e.getClass().getSimpleName() + " " + e.getMessage());
        }
    }

    private void showOverlay(long end) {
        if (root != null) return;
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);

        boolean dark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        int bg = Color.parseColor(dark ? "#0E1612" : "#F4F7F5");

        root = new FrameLayout(this) {
            @Override
            public boolean dispatchKeyEvent(KeyEvent event) {
                return true;          // swallow Back and every other key
            }
        };
        root.setBackgroundColor(bg);

        web = new WebView(new ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault));
        web.setBackgroundColor(bg);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        web.addJavascriptInterface(new Bridge(), "NativeApp");
        web.setWebViewClient(new WebViewClient());
        web.setLongClickable(false);
        root.addView(web, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        web.loadUrl("file:///android_asset/sos.html?end=" + end + "&dur=" + dur);

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                        | WindowManager.LayoutParams.FLAG_FULLSCREEN,
                PixelFormat.OPAQUE);
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        wm.addView(root, lp);
        overlayShown = true;
        web.requestFocus();
    }

    private void removeOverlay() {
        try {
            if (root != null && wm != null) wm.removeView(root);
        } catch (Exception ignored) { }
        try {
            if (root != null) root.removeAllViews();
            if (web != null) web.destroy();
        } catch (Exception ignored) { }
        root = null;
        web = null;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(EXTRA_END).apply();
    }

    /**
     * Holds the screen on for 30 s and restarts the normal screen-off timer afterwards.
     * Without this, the screen (kept on by the lock for 10 minutes without any touch) switched
     * off as soon as the lock was removed.
     */
    @SuppressWarnings("deprecation")
    private void wakeBriefly() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm == null) return;
            PowerManager.WakeLock wl = pm.newWakeLock(
                    PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP
                            | PowerManager.ON_AFTER_RELEASE, "songjom:sosfinish");
            wl.acquire(30_000L);
        } catch (Throwable ignored) { }
    }

    @Override
    public void onDestroy() {
        boolean was = overlayShown;
        removeOverlay();
        if (was) wakeBriefly();
        overlayShown = false;
        super.onDestroy();
    }
}
