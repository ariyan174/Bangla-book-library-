# সংযম (Songjom) – Android project

v2.0 — green instruction card removed from Home, hadith card + SOS buttons back under the day counter, app version shown in the side menu, new menu page "হস্তমৈথুন ও পর্নের ক্ষতি". (v1.9: banner ads on every page, full-screen ad on Back, internet required, copy/select disabled, SOS without screen-pin prompt, rank ladder moved up. Older: side menu, daily habit tracker, diary, Islamic reminders, dhikr counter, ayat, namaz rules & 5 kalima, 10‑minute locked SOS, tap the day number to set days.)

WebView app that needs internet to open (AdMob ads + connection check). Data is stored on the phone (localStorage).
App: package com.songjom.app, minSdk 26 (Android 8.0+), own name, leaf icon, green splash screen.

## Build the APK without a computer (GitHub, from your phone)
1. Create a free account at github.com, then make a new PRIVATE repository.
2. Upload ALL the files of this project (keep the folder structure, including the hidden
   `.github/workflows/build-apk.yml`). Easiest: unzip on a computer/phone file manager and use
   "Add file > Upload files" (drag the folders in).
3. Open the "Actions" tab > "Build APK" > wait ~3-5 minutes for the green tick
   (or press "Run workflow").
4. Open the finished run > scroll to "Artifacts" > download "Songjom-APK" (zip) > unzip > app-debug.apk

## Build with Android Studio
File > Open > select this folder > let Gradle sync > Build > Build APK(s).
APK appears in app/build/outputs/apk/debug/app-debug.apk
(Or in a terminal with Gradle 8.7 + JDK 17 + Android SDK 34:  gradle assembleDebug)
